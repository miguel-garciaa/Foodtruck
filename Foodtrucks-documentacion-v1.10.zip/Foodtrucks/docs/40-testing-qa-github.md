# Testing, QA, GitHub Actions y entrega controlada

**Versión:** 1.9. **Estado:** política de testing, QA y entrega incorporada; implementación futura pendiente. **Fecha de actualización:** 14 de octubre de 2026. Integra los 29 apartados de seguridad/QA recibidos con [controles de seguridad](39-seguridad-devsecops.md), [entornos base](21-entornos-ci-cd.md), [alcance inspeccionado](00-procedencia.md) y la [política canónica de commits, CI/CD y tests](44-politica-commits-ci-cd-tests.md). No hay aplicación, pruebas, workflows ejecutables ni Git/remoto en el material actual. No se ha ejecutado CI, SAST, DAST, carga, build nativa, commit, push o PR de Foodtrucks.

U09 traslada desarrollo y producción a servidor doméstico: [38](38-servidor-domestico.md). La VM dev de 4 vCPU/8 GB/40 GB no garantiza recursos para staging/producción ni builds. Este documento define cómo demostrar los cambios cuando exista el repositorio; no genera ocho workflows genéricos ni publica infraestructura.

## Objetivo, obligaciones y responsables propuestos

El objetivo es que cada cambio coherente pueda relacionarse con comportamiento esperado, pruebas ejecutadas, commit/push, CI del SHA exacto y artefacto promovido. GitHub Actions será el mecanismo de CI/CD y GHCR el registro previsto. Staging se desplegará automáticamente tras los gates de una fuente confiable; producción exigirá aprobación manual y usará el mismo digest validado. Son decisiones de política, no cuentas, workflows, imágenes o despliegues existentes.

| Función propuesta | Obligación de la función | Criterio de aceptación |
| --- | --- | --- |
| Autor o agente local | Implementar bloques coherentes, respetar cambios ajenos y cerrar cada bloque con commit/push autorizado | Diff propio revisado, pruebas justificadas y registro real del SHA/push; sin auto-merge ni force-push |
| Responsable de QA | Seleccionar casos por riesgo, mantener fixtures aisladas y tratar regresiones/flakes | Pruebas relevantes ejecutadas con resultados y cobertura útil, sin ocultar errores |
| Responsable de DevSecOps | Mantener comandos reproducibles, gates y separación de confianza | Gate estable que rechaza controles ausentes/fallidos y CI asociada al SHA exacto |
| Revisor humano autorizado | Revisar cambios y aprobar conforme a las reglas reales | Aprobación independiente auténtica de la versión vigente cuando proceda |
| Responsable de release/operación | Validar capacidad, staging, digest, migración y recuperación | Staging automático verificado y autorización manual concreta antes de producción |

Asignar personas, permisos, suplencias y canales al disponer del equipo y cuentas. Que una función figure aquí no acredita una revisión ni concede acceso. La secuencia canónica y los límites del agente local están en [44](44-politica-commits-ci-cd-tests.md); este documento desarrolla qué se prueba y cómo se acepta.

### Decisión de pruebas obligatoria por cambio

Registrar una de estas decisiones y su evidencia: **test nuevo** para comportamiento/riesgo sin cobertura; **test adaptado** si cambia un contrato cubierto; **test existente ejecutado** si ya demuestra el comportamiento relevante; **sin test (justificado)** para un cambio que razonablemente no lo necesita, manteniendo los controles aplicables. Las pruebas nuevas/adaptadas también se ejecutan; escribirlas no acredita resultado. La justificación identifica alcance y riesgo, por ejemplo corrección documental sin código con validación de enlaces/coherencia, y no exime pruebas relevantes de auth, permisos, pagos, concurrencia o regresión. No crear tests que reflejen mecánicamente la implementación.

La ficha del bloque conserva rutas, tipo de prueba, comandos por carpeta, resultados reales, tests previstos/ejecutados y motivo de exclusión, junto con revisión, SHA y CI. Comando correcto con cero tests relevantes no demuestra el caso previsto. Esta iteración solo permite comprobaciones documentales; no afirmar tests de aplicación ni sustituirlos por búsqueda de palabras.

## 1. Primera iteración con código disponible

Inspeccionar README/AGENTS y archivos antes de modificar: git status/diff, rama/remotos, cambios ajenos, manifests/lockfiles, módulos Go, workspaces, scripts, versiones, router, nativo prebuild/bare, SQL/migraciones, Docker/Caddy y workflows/despliegue reales. Guardar un inventario saneado, sin copiar secretos ni configs completas. Obtener baseline de tests/build/cobertura ejecutados y distinguir fallos previos de regresiones propias.

Primero confirmar contratos sensibles y permiso de ejecución; después priorizar correcciones y tests por bloque. No inicializar una app/repo/GitHub de nombre supuesto para fingir esta auditoría. foodtrucks.com es referencia sin control probado; no probar a ciegas el sitio de un tercero.

Si falta un comando/script/módulo, registrarlo como pendiente o fallo de setup, no aprobar por omisión. Si un componente no existe en una iteración inicial, su check puede ser no aplicable con motivo verificable; un componente existente cuya configuración/test falta no pasa a no aplicable. No eliminar cambios ajenos ni ampliar arquitectura por preferencia.

## 2. Pirámide y selección de herramientas

| Nivel | Qué valida | Base propuesta y límites |
| --- | --- | --- |
| Unitario/domain | Precio entero, descuento aprobado, estado, elegibilidad, serialización y validaciones | Go testing/subtests/fuzzing; frontend Jest/Vitest según proyecto real |
| Componente | Interacción visible, errores, accesibilidad, tema y estados de carga | Testing Library web/nativa compatible; sin verificar solo que renderiza |
| Integración | API Chi, auth, SQL real, transacciones, caché/outbox y workers | PostgreSQL/PostGIS y Redis de prueba aislados; pgx/sqlc, no SQLite sustituta |
| Contrato/proveedor | DTO/API, firmas, idempotencia, errores y cuenta/entorno | Fakes en frontera + sandboxes reales controlados para casos que los necesiten |
| E2E web | Recorridos Next.js → Go → DB y roles | Playwright TypeScript compatible; pocos recorridos críticos |
| E2E nativo | SDK nativo, enlaces, permisos, mapa, pago, QR, notificaciones | Maestro o Detox a evaluar; dispositivos/development/release builds |
| Operación | Artefacto, TLS/proxy, migración, smoke, backup/restore y rollback | Staging propio; efectos externos desactivados |

Go primero testing/httptest y herramientas estándar. Usar tablas de casos/subtests y resultados observables; t.Parallel solo con fixtures independientes. Race detector comprueba carreras de memoria ejecutadas, no sustituye los tests de concurrencia económica en DB. Fuzzing con corpus saneado valida parsers/geometría/IDs/aritmética donde aporte; no usar float para dinero. [Go testing](https://pkg.go.dev/testing), [race detector](https://go.dev/doc/articles/race_detector), [fuzzing](https://go.dev/doc/security/).

Para Expo revisar SDK antes de Jest/jest-expo y React Native Testing Library; Jest/Vitest web según scripts existentes. Tests JS no ejecutan módulos Swift/Kotlin reales ni acreditan firma/push/Mapbox. No añadir Maestro y Detox simultáneamente sin necesidad. [Expo unit testing](https://docs.expo.dev/develop/unit-testing/), [React Native testing](https://reactnative.dev/docs/testing-overview).

Mocks/fakes pequeños de servicios externos; integration/E2E crítico atraviesa API propia y datos reales de prueba. Mock de todo el checkout no demuestra autorización, persistencia o pago reconciliado. OAuth/mapa/SDK externos necesitan pruebas específicas de compatibilidad fuera de CI rápido. Fakes de firma/cobro no sustituyen la prueba sandbox de Stripe. No instalar gotests/testify/goleak, Testcontainers u orquestación adicional sin beneficio concreto.

## 3. Matriz de comportamiento y riesgos

Todos los casos usan datos sintéticos y assertions sobre resultado, DB/eventos y ausencia de efectos indebidos. La numeración QA es interna; no indica tests implementados.

| ID/área | Happy path y negativos esenciales | Evidencia/prueba |
| --- | --- | --- |
| QA01 Identidad | Registro/login/logout; contraseña inválida, email duplicado no enumerativo, token exp/repetido, refresh concurrente, sesión revocada/Redis caído | API/direct handler + integración de sesiones + flujo web/nativo |
| QA02 Google/Apple | iss/aud/firma/nonce/state/PKCE/redirect según flujo; email coincide pero no prueba control; nombre/relay Apple ausentes | Fakes contractuales + callback y sandbox/control de cuenta autorizado |
| QA03 Permisos | Cliente A no ve pedido/ticket/saldo B; comerciante X no ve/edita Y; rol enviado no eleva; miembro retirado pierde conexión | Tabla API 39, listados/anidados/exportaciones y tiempo real |
| QA04 Descubrimiento | Publicado con carta/ubicación vigente; oculto no aparece; bbox/radio/NaN/cursor/rangos enormes inválidos | PostGIS real, JSON/DTO público, paginación y tiempos medidos |
| QA05 Carta/fotos | Precio/opciones/alérgenos válidos; producto ajeno, cantidad límite, MIME falso/traversal/bomba de dimensiones/cuota | API/SQL/media controlado; render no ejecuta contenido |
| QA06 Cotización | Total entero/moneda/reglas; precio/discount/saldo cliente ignorados o rechazados, overflow y cambio de precio | Unitario + integración autoritativa; no inventar impuestos/ratios |
| QA07 Pedido/stock | Un pedido por clave; clave con payload distinto conflicto; dos compradores de última unidad o franja | Barrera de concurrencia DB real; política P07/P08 previa |
| QA08 Pago | Crear/recuperar mismo contexto; fallo/timeout incierto, 3DS/cancelación cuando aplique, frontend declara paid | Fake externo controlado + Stripe sandbox; verificar un cobro/estado autorizado |
| QA09 Webhooks | Firma raw body/entorno/cuenta/importe correctos; false/replay/duplicado/desordenado/body grande/DB caída | Persistencia y dedup; ACK no precede commit; retry/conciliación |
| QA10 Estados | Aceptar/preparar/listo/recoger según máquina aprobada; salto ilegal o versión vieja | Unitario de transición + integración atómica + cola comerciante |
| QA11 QR | Pedido propio listo/pagado; comercio ajeno/QR impagado/cancelado; dos scans simultáneos | Una redención DB, resultado coherente; token ausente en logs/URL pública |
| QA12 Billing | Cliente 5,99 €/mes separado de licencia/comerciante; derechos falsos, doble alta, eventos atrasados | Sandbox/fakes y proyecciones; impuestos/baja/canal aún pendientes |
| QA13 Fidelización | Un crédito por origen; doble gasto/cupo desde dos dispositivos; reserva vence+pago tardío; refund parcial repetido | Ledger/compensación+proyección transaccional; reglas P30–34 previas |
| QA14 Redis/outbox | Commit → invalidación; relleno obsoleto, Redis caído, worker muere/reintenta y evento repetido | No fuga entre actores, autorización duradera y efecto único lógico |
| QA15 Resend | Destinatario/finalidad, firma/reintento/dedupe, baja/rebote/queja, link exp/GET escáner | Sink/fake CI; allowlist staging; no envío real por restaurar backup |
| QA16 Avisos | Token propio/app/entorno; denegado/expirado, desconexión/orden duplicado y fallback | Fake CI + dispositivos reales APNs/FCM/Activities/Updates |
| QA17 Navegación nativa | Deep/universal/app link válido/cold/warm; ruta/host inválido, permiso geolocalización/cámara rechazado | iOS/Android compatible; cambios de cuenta no conservan privados |
| QA18 UI/a11y | Claro/oscuro/sistema, teclado/foco/error/lector/tamaño de fuente/reduced motion | Web: axe y revisión manual; móvil VoiceOver/TalkBack y dispositivos |
| QA19 Marketing/datos | SEO publicado/metadata/JSON-LD/sitemap; rechazo/retirada de consentimiento desde arranque | No PII/tokens/QR en URL/evento, conversiones dedup, privado no indexado |
| QA20 Infra/release | TLS/renovación, Cloudflare API sin challenge, puerto privado; migración y restore sin side effects | Entorno propio, exposición externa controlada; sólo ejecución autorizada |

Cuando una política comercial está pendiente, verificar invariantes independientes y documentar las pruebas afectadas como pendientes. No completar un test de refund inventando el derecho a reembolsar. Escenario de recogida presencial: no hay delivery, repartidor o tracking de un conductor.

### Concurrencia y consistencia reproducibles

Usar dos clientes/goroutines y conexiones SQL separadas, una barrera para iniciar juntas, deadline y repetición justificada. Assert sobre unicidad/stock/ledger/estado/outbox y resultado de cada operación, no solo status 200. Un test envuelto siempre en una única transacción que luego se revierte no reproduce correctamente dos commits competidores.

Fixtures independientes por test/worker y reloj controlable para expiración; health/readiness en vez de sleeps fijos. No TRUNCATE, borrado de volúmenes o migraciones destructivas sobre un DSN ambiguo. Guardrail de entorno/nombre/origen de DB de pruebas, credenciales limitadas y teardown exclusivo de recursos creados por la suite. Probar locks/deadlocks/retry de la estrategia elegida con límites, sin ocultar errores transitorios.

### Pagos, correo, push y publicidad en pruebas

CI rápido: Stripe fake/fixtures saneadas, Resend sink/fake, push fake, Mapbox fixtures cuando baste, Google/Apple exchange simulado y salidas de analítica/publicidad bloqueadas. Integración con proveedor: sandbox/test accounts propias y entorno separado, trigger confiable y credenciales mínimas; nunca tarjeta, destinatario, dispositivo o cuenta live de usuario. Stripe CLI puede servir para forwarding/eventos de prueba si ya está instalada/configurada, sin exponer tokens. [Pagos](13-stripe.md), [correo](30-correo-resend.md).

Resend no se presupone sandbox que impide mandar a personas reales: allowlist de cuentas de prueba si se activa staging. AdMob TestIds cuando se evalúe, AdSense flags/slots live desactivados; ni clicks reales de prueba, ni compras, ni conversions live, ni emails a terceros desde CI. Restaurar DB exige desactivar workers/efectos antes del primer arranque. [Publicidad](33-monetizacion-adsense-admob.md), [medición](34-analitica-consentimiento.md).

## 4. E2E web, nativo, regresión y accesibilidad

Web: visitante explora negocio publicado/carta; cliente autenticado compra de prueba y recupera pedido; comerciante autorizado prepara y canjea; otros actores reciben denegación. Habilitar checkout web solo si P09 lo incluye; paneles/descubrimiento se prueban según alcance realmente implementado. Usar locators por rol/etiqueta, assertions con espera automática, contexto por usuario y fixtures aisladas. No sleeps para esconder carreras ni shared storageState privado entre usuarios. [Playwright best practices](https://playwright.dev/docs/best-practices).

No instrumentar un E2E completo por cada combinación ya probada abajo. Capturar trace/screenshot/video al fallo con retención y saneamiento; un HAR/storageState puede contener credenciales y no se añade a Git sin revisión. Retries limitados son diagnóstico, no aprobación de tests intermitentes. Registrar flake y corregir causa; repetir cinco veces solo por una preocupación concreta, sin coste obligatorio por toda PR. POM se usa si reduce repetición real; no una clase por fragmento.

Nativo: tests de componentes y pocos recorridos Maestro/Detox si compensan, development build para Mapbox/módulos, release para rendimiento. Matriz pendiente: dispositivo/SO/mínimos, iOS/Android, 60/90/120 Hz cuando compatibles, permiso denegado, red lenta/offline, app fría/caliente, cambio de sesión y ambos temas. Verificar firma, links, Apple/Google, QR/cámara, push y superficie de SO antes de release. Emulación web móvil de Playwright comprueba navegador responsive, **no** React Native ni 120 FPS.

Regresión: reproducir el defecto confirmado con prueba que falla en la versión previa y pasa con corrección, cuando sea practicable; conservar evidencia sin reintroducir fallo en rama de entrega. No tests que reflejen nombres internos o snapshot gigante como sustituto de comportamiento. Revisión de assertions y ramas límite, error externo, recursos inexistentes/permisos y concurrencia.

Accesibilidad: controles etiquetados, focus management, teclado y lector, contrastes en ambos temas, estado comunicado y tamaño de texto. Probar header/menú responsive web y dock únicamente nativo; mapa debe ofrecer alternativa usable/lista, no depender solo de color/posición/gesto. axe automatiza parte; teclado/VoiceOver/TalkBack requieren revisión real. Ningún porcentaje automático equivale a cumplimiento universal. [Diseño](05-design-system.md).

## 5. Cobertura, rendimiento y calidad de datos

Baseline al existir tests. Publicar cobertura de módulos/rutas críticas y ramas no probadas junto con calidad de assertions. Umbral progresivo por riesgo y cambio, pendiente hasta observar baseline; no imponer 100 % ni un 80 % inventado global. No excluir código crítico para inflar porcentaje. Perfil Go/Lcov y reportes compatibles con herramientas elegidas, retenidos sin datos privados.

Carga controlada de descubrimiento/PostGIS, carta, auth, cotización/pedido/transición: plan con entorno propio, volumen/duración, usuarios concurrentes, dataset, ramp-up, stop conditions y presupuesto. k6 es candidato, no instalado ni ejecutado. No cargar producción o la red doméstica compartida sin autorización; tampoco activar pagos/emails/promociones durante el test. Registrar p50/p95/p99, errores, throughput, CPU/RAM/disco/I/O/conexiones y terceros separados. [k6](https://grafana.com/docs/k6/latest/testing-guides/).

120 FPS según [16](16-rendimiento.md): release/dispositivo real, tiempos de frame y dropped frames, gestos/mapa/fotos/tema, memoria/batería/temperatura. Targets p95/p99 y pérdidas aceptables pendientes; la bandera ProMotion no demuestra FPS. Comparar antes/después con misma escena/dataset. Core Web Vitals campo y laboratorio diferenciados; no usar Lighthouse como prueba del objetivo nativo.

Datos: fixture válido geográfico, timestamps/moneda, constraints/relaciones, pipeline de migración/sqlc y contratos TS; no ciudades/reseñas/ofertas ficticias publicadas. La venta/refund/QR viene de Go/Stripe/DB. GA4/Firebase comprueba consentimiento, deduplicación por origen, eventos fuera de orden y no fuga; dashboard no sustituye reconciliación del backend. [Observabilidad](41-observabilidad-grafana-prometheus-sentry.md).

## 6. Quality gates y seguridad automatizada

La clasificación siguiente es propuesta de política para cuando haya código. Obligatorio falla → integración bloqueada. Informativo/periódico/manual no significa ignorar un crítico confirmado; los hallazgos relevantes se triagean. No silenciar alertas ni continuar con fallo para una build verde.

| Control | Clase propuesta | Implementación/evidencia futura |
| --- | --- | --- |
| gofmt, go vet, lint, TypeScript y formato JS/TS | Obligatorio por componente | Comandos existentes + reportes/exit code; gofmt sin archivos pendientes; sin warning relevante oculto |
| Unitarios y contratos críticos | Obligatorio | Auth/permisos/precios/transiciones; módulo afectado y dependencias |
| Integración PostgreSQL/PostGIS/Redis | Obligatorio cuando cambien datos/auth/compra/cache/outbox | Migraciones/constraints/concurrencia reales |
| Build Go/web y validación JS móvil | Obligatorio por componente afectado | Versiones/lockfiles/diffs identificados; JS móvil no es build nativa |
| E2E crítico existente | Obligatorio según cambio/contrato | Recorrido crítico estable; no salto por conveniencia |
| Secret scanning del cambio | Obligatorio en todas las PR | Gitleaks/revisión de allowlist; historial baseline inicial y periódico |
| SCA Go/Node e imágenes producidas | Obligatorio en CI del componente; imagen antes de release y baseline periódico | govulncheck, auditoría del gestor y scan de imagen real; críticos/altos aplicables triageados |
| SAST | Obligatorio en módulos críticos tras configurar herramienta compatible | CodeQL si elegible o alternativa revisada; baseline y excepciones específicas |
| Dependency Review | Obligatorio para deps cuando disponible | Availability/plan verificados; fallback SCA/revisión si no hay feature |
| SBOM/licencias y procedencia | Obligatorio para release; informativo en PR inicial según alcance | Artefacto/digest/commit, licencias y componentes copiados |
| DAST limitado | Periódico y antes de piloto relevante | Solo staging propio autorizado; sin privilegios/live/ataque agresivo |
| Fuzz prolongado/carga/CWV | Periódico y ante riesgo/regresión | Duración y presupuesto medidos; baseline reproducible |
| Nativo firmado/tienda/FPS | Manual o job de release aprobado | Dispositivo/build real, cuentas/firma/costes y autorización |
| a11y manual, revisión independiente, restore/rollback | Manual en hitos/cambios relevantes | Evidencia real y responsable; no checkbox automático |

govulncheck identifica vulnerabilidades Go relevantes al código; no prueba ausencia general de fallos. OSV-Scanner es opción SCA adicional si aporta cobertura, Trivy para imagen/config cuando existan y ZAP baseline para exploración DAST limitada: escoger cobertura útil evitando scans duplicados. ZAP baseline hace crawling/peticiones incluso si su análisis es pasivo, por lo que necesita entorno y límites. [Go security](https://go.dev/doc/security/), [OSV-Scanner](https://google.github.io/osv-scanner/), [Trivy](https://trivy.dev/), [ZAP baseline](https://www.zaproxy.org/docs/docker/baseline-scan/).

Las prestaciones CodeQL/Dependency Review/secret scanning/rulesets/environments dependen de visibilidad, propietario y plan. No comprar ni prometer extras gratuitos en privado. [GitHub security features](https://docs.github.com/en/code-security/getting-started/github-security-features), [Dependency Review](https://docs.github.com/en/code-security/concepts/supply-chain-security/dependency-review).

## 7. CI mínima del monorepo, ampliable con evidencia

Reutilizar workflows reales antes de crear archivos. Base inicial: un ci.yml con detección de cambios, jobs por componente y check agregador estable; security.yml separado solo si lo requieren permisos/cadencia. Release/CD van separados por confianza. No son ficheros implementados en este paquete.

| Job lógico | Rutas que lo activan — ajustar al repo real | Trabajo |
| --- | --- | --- |
| cambios/contratos/secretos | Toda PR; cambios de workflow, root manifests/locks/config afectan alcance | Registrar plan de jobs, links/contratos y secret scan |
| go | backend/, database/, contratos compartidos, tooling/imagen Go | Formato/vet/unit/race, integración necesaria, sqlc, build y SCA |
| web | apps/web/, api-client, design-tokens, manifests/locks/root config | Frozen install, formato/lint/TS/unit, build y E2E crítico según cambio |
| mobile-js | apps/mobile/, contratos/tokens/locks/config | Compatibilidad Expo, formato/lint/TS/componentes y validación bundle según scripts |
| infraestructura/build | Compose/Caddy/Dockerfiles/scripts/workflows y cambios de runtime | Validación config, build/scan de imágenes aplicables, sin secretos/producción |
| gate | Toda PR, aunque fallen o se salten jobs anteriores | Comprueba resultados obligatorios esperados y motivo de no aplicable |

Cambios Go/API/SQL/contratos deben poder activar también consumers/E2E; no filtrar solo por carpeta de pantalla. Cambios de lockfile/toolchain/workflow/config compartida obligan a reevaluar todos los componentes afectados. PR documental mantiene integridad de links/secret scan, no afirma haber probado una app inexistente.

El workflow que aporta el check obligatorio debe ejecutarse siempre en los eventos/ramas exigidos; no aplicar filtros paths/branch que impidan crearlo. La selección por cambios se realiza dentro del workflow y publica un plan explícito de jobs/checks esperados. El detector de alcance no puede confiar en una omisión solicitada desde código de PR para conceder privilegios o reducir controles. Contratos, dependencias, migraciones, root config y workflows amplían el alcance de sus consumidores.

El gate final estable usa `needs` y `if: ${{ always() }}` para inspeccionar resultados incluso después de un fallo/salto; su trabajo solo agrega evidencia, con timeout y sin checkout, despliegue ni tareas privilegiadas. La política es **fail-closed**: job/check ausente, output del detector inválido, comando/script/herramienta faltante, failure, cancelled o unexpected-skipped bloquean. Solo acepta success real de todos los controles exigidos y omisiones previstas por el plan con motivo verificable. No usar `continue-on-error`, `|| true`, `--if-present`, catch silencioso o un job vacío para transformar un control obligatorio fallido en verde. Si el gate no se ejecuta/finaliza, no hay aceptación. [GitHub expresiones y always](https://docs.github.com/en/actions/reference/workflows-and-actions/expressions#always).

Cada push de cierre debe tener una ejecución de GitHub Actions cuyo `head_sha` coincida con el SHA exacto enviado, con origen y nombre de check esperados. Registrar además checkout/artefacto; una prueba sobre commit sintético de merge de PR se identifica como tal y complementa la comprobación del commit enviado. Un verde antiguo, de otra rama, SHA o workflow no sirve. Si se adopta merge queue, incluir merge_group y verificar también su candidato. Al corregir un fallo: cambio coherente → pruebas/revisión → nuevo commit/push → CI del nuevo SHA según [44](44-politica-commits-ci-cd-tests.md). [GitHub required checks](https://docs.github.com/en/pull-requests/how-tos/merge-and-close-pull-requests/troubleshooting-required-status-checks).

La aceptación futura del gate debe demostrarse con fallos controlados: test/lint fallido, script ausente, detector fallido, job obligatorio cancelado/saltado y cambio compartido que afecta varios componentes deben bloquear. Un cambio documental verificado puede omitir builds de componentes según plan, pero conserva integridad documental y secret scan. Estas pruebas del pipeline siguen pendientes; no se han realizado en este paquete.

### Comandos de referencia, no ejecutados

Desde backend/ **solo cuando existan go.mod, herramientas y rutas propuestas**:

~~~bash
gofmt -l .
go vet ./...
go test ./...
go test -race ./...
govulncheck ./...
go build ./cmd/api
go build ./cmd/worker
go test -coverprofile=coverage.out ./...
go tool cover -func=coverage.out
~~~

Si se adopta separación de integración por build tag, añadir go test -race -tags=integration ./... con PostgreSQL/PostGIS y Redis de prueba preparados. Race no sustituye dos conexiones/commits SQL concurrentes ni la prueba de idempotencia de Stripe/QR. Regeneración sqlc y gofmt se convierten en scripts reproducibles con tools/versiones fijadas; el check gofmt debe fallar cuando `gofmt -l` produzca rutas, ya que listar rutas no falla por sí mismo. govulncheck requiere herramienta y configuración verificadas; si falta, el control obligatorio queda fallido/pendiente, no verde. No usar APIs nuevas de testing citadas en una skill hasta confirmar versión Go real.

Frontend: elegir npm/pnpm del lockfile; npm ci o pnpm install --frozen-lockfile; después scripts **realmente definidos** lint/typecheck/test/build en cada workspace. Playwright test requiere configuración y browsers de versión correspondiente; no suponer que npm run build prueba iOS/Android. Registrar el comando final por carpeta una vez exista el código, sin usar --if-present para aprobar una comprobación obligatoria ausente.

### Seguridad y coste de Actions

Por defecto GITHUB_TOKEN solo lectura, permisos adicionales por job y propósito. Checkout sin persistir credenciales; **CI no hace auto-commit, push de correcciones, auto-merge ni cambios de protección**. El agente local crea y sube sus cambios conforme a [44](44-politica-commits-ci-cd-tests.md). PR/fork se valida sin secretos de proveedor/firma/publicación/despliegue y sin runners con acceso a producción, al host o a la LAN doméstica. Nunca ejecutar head de PR no confiable mediante pull_request_target/workflow_run privilegiado. Inputs/títulos/branches no se interpolan en shell; tratar artefactos/caches como potencialmente manipulables.

Revisar fuente/origen de actions y versiones. La guía GitHub actual presenta workflow dependency lockfiles como protección de dependencias transitivas; si se adopta, verificar compatibilidad. Alternativa: SHA completo verificado del repositorio real y política de actualización, no un hash inventado ni @latest. [GitHub secure use](https://docs.github.com/en/actions/reference/security/secure-use), [pull_request_target](https://docs.github.com/en/actions/reference/security/securely-using-pull_request_target).

Time limits, concurrency por PR con cancelación de builds obsoletos; no cancelar una migración/despliegue a mitad por la misma regla. Cache por OS/toolchain/lockfile y ámbito de confianza, sin secretos; artefactos con acceso/retención según datos. No cachear bases con datos reales ni compartir storageState privado. CI nativa/macOS puede costar más: definir frecuencia y presupuesto en [costes](37-costes-presupuesto.md), sin compras automáticas. Sharding/matriz extra solo cuando tiempos medidos lo justifiquen.

## 8. CD a desarrollo, staging y producción doméstica

Separar dominios/orígenes, DB, Redis, volúmenes, usuarios, secrets, app IDs y proveedores por entorno. Development con datos ficticios; staging propio de prueba antes de producción; producción con datos reales y permisos mínimos. Si comparten hardware, aislar VMs/recursos/red y medir competencia; no convertir dev en staging renombrando variables. Capacidad, dirección/CGNAT/conectividad, backup externo y operación todavía se verifican según [38](38-servidor-domestico.md).

Política de entrega: GitHub Actions construye imágenes desde un SHA confiable con gates correctos y las publica en **GHCR**; la rama/tag de integración real queda pendiente de inventario. El job de publicación tiene únicamente permisos necesarios (`packages: write` cuando proceda); los jobs de PR no publican imágenes de release ni acceden a credenciales de despliegue. Mantener un manifiesto de release con SHA, digest de cada servicio, migraciones, versión de configuración y evidencia de scan/procedencia sin secretos. El servidor descarga solo los paquetes autorizados con permisos de lectura. [GitHub Container registry](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry).

**Staging automático:** tras CI/build/scan correctos de una fuente confiable, desplegar la imagen por digest en staging aislado, ejecutar migración controlada y smoke/integración. **Producción manual:** requiere staging correcto y aprobación humana explícita para ese release, destino, migración y digest; promover exactamente la misma imagen sin reconstruirla. Si hay varias imágenes, promover el mismo conjunto de digests del manifiesto. Un tag mutable como latest no es identidad de release. Configuración/secretos se inyectan por entorno; ninguna diferencia que altere el bundle puede ocultarse tras un rebuild no validado. [44](44-politica-commits-ci-cd-tests.md) fija esta regla.

No compilar código de PR arbitraria en la máquina que conserva usuarios/pagos/backups. GitHub Actions, GHCR, scanners, firma/procedencia, staging y rollback descritos aquí son futuras implementaciones: no se han creado workflows, paquetes, cuentas, imágenes o accesos.

SSH/transferencia con host key verificada y cuenta limitada, o entrega pull por agente dedicado que verifica artefacto; VPN/canal de red privado a definir. No abrir SSH a Internet solo para que Actions llegue; no StrictHostKeyChecking=no. OIDC solo si registro/proveedor admite federación y política de claims acotada; no reemplaza por sí mismo SSH de un servidor doméstico. Nunca instalar runner persistente de PR con Docker socket/red familiar/privilegios del host. [GitHub OIDC](https://docs.github.com/en/actions/reference/security/oidc).

Secuencia futura:

1. Verificar CI/gates/revisión del SHA exacto, artefacto/digest/origen y elegibilidad de la fuente confiable.
2. Validar configuración requerida, espacio/capacidad, health, backup recuperable y compatibilidad de migración.
3. Desplegar automáticamente ese digest en staging, migración controlada única, smoke/flujo de prueba y evidencias; probar rollback compatible.
4. Preparar release y solicitar aprobación manual de producción: hostname/host/digest/migración exactos, no permiso genérico por calendario.
5. Tras la aprobación, promover el mismo digest a producción con bloqueo de concurrencia y procedimiento conocido; observar servicio/error/latencia y reconciliación.
6. Registrar release/responsable/resultados; si falla, contener y aplicar rollback aprobado y compatible.

Compose no garantiza cero downtime. Blue/green/canary solo si puertos, recursos, pool DB, sesiones y capacidades reales lo permiten; no duplicar toda la pila sobre 8 GB por receta. Baseline reversible puede ser sustitución controlada con ventana acordada. Rollback de imagen no revierte esquema destructivo, email, cobro o puntos externos; migraciones expand/contract y compensaciones según [21](21-entornos-ci-cd.md). No rollback automático de producción sin política explícitamente aprobada.

GitHub Environments/protecciones se configuran solo con permisos y autorización correspondientes. En privados, disponibilidad de environments/reviewers varía por plan; si falta una protección no afirmar que existe ni desplegar sin aprobación. Mantener despliegue de producción manual controlado hasta tener mecanismo equivalente verificable o plan elegible. [GitHub environments](https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments).

Móvil: build de validación, signing, beta/TestFlight y App Store/Google Play son fases distintas de deploy Compose. Cuentas, certificados, versión/build number, entitlements, SDK/canal de membresía y aprobación de publicación antes de distribuir. OTA no entrega módulos nativos nuevos ni exime compatibilidad con apps ya publicadas. EAS es opción pendiente, sin compra/build/publicación autorizada por instalar una skill.

## 9. Ramas, commits, push, revisión y PR

main protegida como propuesta; PR y checks críticos requeridos, revisión independiente proporcional, resolución de conversaciones y no force push/deletion/bypass indiscriminado. CODEOWNERS para auth/pagos/SQL/workflows según personas/equipos reales; no inventar handles. Comprobar plan/visibilidad y export/diff de reglas antes de cambiarlas con autorización. Si hay un único desarrollador, registrar limitación y organizar revisión externa cuando la política la exija, sin autoaprobación ficticia. [GitHub rulesets](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets).

Conventional Commits con feat/fix/test/ci/build/refactor/perf/docs/chore; security es tipo adicional solo si tooling lo reconoce, alternativa fix(security). Asunto específico, cuerpo para motivo/impacto/validación real. Ejemplos de estructura, no commits creados: fix(orders): impedir acceso entre negocios; test(pickup): cubrir canje simultáneo; ci(checks): verificar gates del monorepo. No describir una vulnerabilidad como corregida sin evidencia, ni decir tests pasan si no se ejecutaron.

Antes de cada commit: status → diff → diff --check → cambios ajenos/secretos/generated files → tests/lint/format/build pertinentes → stage solo ficheros previstos → commit → inspección del commit final. Hook falla: corregir causa, sin --no-verify. Nunca git add indiscriminado, borrar cambios ajenos o force push. No crear commits en esta carpeta sin Git para aparentar trazabilidad.

Con remoto/acceso autorizado: verificar origin/base/branch y actualizar refs sin sobrescribir trabajo; usar rama descriptiva. **Tras cada cambio coherente**, ejecutar pruebas/controles pertinentes, revisar y crear un commit atómico que incluya exclusivamente cambios propios; inspeccionarlo y hacer push de esa rama sin esperar a agrupar cambios independientes. Abrir o actualizar la misma PR y comprobar GitHub Actions para el SHA exacto enviado. Si falla CI, analizar la causa, corregir y repetir el cierre por nuevo commit/push/CI; no ocultar el fallo ni dar por terminado el bloque. Un cambio coherente es una unidad revisable, no cada edición de una línea. La secuencia y las decisiones de pruebas se rigen por [44](44-politica-commits-ci-cd-tests.md).

El alcance de la política no prueba que exista acceso; no inventar push/URL/hash. Sin Git/remoto autorizado se registra el bloqueo específico y lo preparado realmente. No push directo a main, force-push, auto-merge, autoaprobación ni publicación productiva por completar el push. Merge, aprobaciones independientes y producción permanecen etapas separadas. PR creada se adjunta al chat mediante herramienta de artefactos disponible cuando realmente exista.

Review: corrección/permisos/regresión, errores/recursos/concurrencia, SQL/migración/deps, frontend/a11y/performance y complejidad. Hallazgos: bloqueante/alto/medio/bajo/mejora, con evidencia/impacto/test. Corregir relevantes y volver a verificar sin scans repetidos arbitrarios. IA/subagente son revisión automatizada, no aprobación humana ni independiente de CODEOWNERS. No autoaprobar PR para cumplir una regla de tercero.

La PR explica problema y comportamiento final, alcance/archivos, controles de seguridad, comandos/resultados reales, CI afectada, riesgos, deploy/config/migración y rollback. Checklist con hecho comprobado, pendiente/no aplicable y motivo; no todos los checks marcados por plantilla. No publicar PII, secretos, payloads o hashes ficticios. Reutilizar plantilla del repo si existe; CONTRIBUTING/SECURITY/CODEOWNERS/templates solo cuando aportan y propietarios/política están definidos.

## 10. Fases A–G y definición de terminado

| Fase | Resultado verificable futuro | Estado actual |
| --- | --- | --- |
| A Auditoría | Inventario real Git/código/versions/tests/workflows/infra, baseline y riesgos con evidencia | Material documental inspeccionado; auditoría app pendiente por ausencia de repositorio |
| B Seguridad crítica | Auth/permisos/precios/pagos/QR/puntos/secretos corregidos y probados por bloque | Requisitos 39; no correcciones de app |
| C Testing | Matriz crítica ejecutable, integración/concurrencia y E2E/regresión con reports | Plan 40; no tests app |
| D CI | GitHub Actions ejecutado para el SHA exacto enviado; gate always fail-closed probado y scans reales | Política; ninguna ejecución Actions |
| E CD | Imágenes GHCR por digest; staging automático; producción con aprobación manual del mismo digest y rollback probado | Política condicionada al host/cuentas; no build, scan, paquete o despliegue |
| F GitHub | Política/owners/protecciones/Dependabot/PR reales y checks del commit vigente | Acceso/repo/plan por aportar; no cambios remotos |
| G Calidad | Baselines/SLO/observabilidad/restore/performance y documentación operables | [41](41-observabilidad-grafana-prometheus-sentry.md) y plan; no métricas de app |

Un cambio de código terminado requiere implementación, revisión, decisión de pruebas con evidencia y pruebas relevantes/build/gates aplicables ejecutados y correctos, secretos controlados y documentación. Cada bloque coherente requiere commit atómico/push autorizado desde el agente local y CI correcta para el SHA exacto; un bloqueo externo pendiente se comunica, no se transforma en terminado. Aplicar [44](44-politica-commits-ci-cd-tests.md), con rama/PR y reglas reales. La fusión exige aprobaciones independientes; publicación productiva es etapa separada con aprobación manual, staging correcto y mismo digest. Documentación terminada significa archivos coherentes/enlaces/paquete comprobados, no Fases B–G implementadas.

Informe por iteración: analizado, problemas/hipótesis/hallazgos confirmados, archivos/correcciones, decisión de tests nuevos/adaptados/existentes/sin test justificado y comandos/resultados, build/workflows/CI, commit/SHA exacto/rama/push/PR reales si existen, digest y staging, revisión automática/humana diferenciada, aprobación manual de producción pendiente/concedida, riesgos residuales y siguientes pasos. Un informe sin código dice no aplicable/pendiente en esos campos, no inventa hashes ni verde.

Estados: implementado y comprobado; implementado pero no comprobado; pendiente; bloqueado por condición concreta; requiere aprobación; no aplicable con motivo. Un límite temporal de herramientas no cancela tareas pendientes; al restablecerse, continuar el trabajo autorizado preservando estado, como ha solicitado el usuario.

## 11. Cobertura de los 29 apartados incorporados como políticas

La matriz conserva la trazabilidad de los requisitos recibidos hacia obligaciones y aceptación del proyecto. No conserva una copia del prompt ni declara ejecutada una auditoría de aplicación. Los cambios posteriores de la política canónica [44](44-politica-commits-ci-cd-tests.md) rigen el cierre de cada bloque y la promoción del artefacto.

| Apartado | Política incorporada y ubicación | Evidencia de aceptación futura |
| --- | --- | --- |
| 1 Rol y responsabilidades | 39 y 40: funciones propuestas de ingeniería, seguridad, QA, DevSecOps, revisión y operación | Propietarios asignados y responsabilidades verificables |
| 2 Contexto | Go/Chi/pgx/sqlc, PostgreSQL/PostGIS, Redis justificado, Next.js, Expo/React Native y recogida sin delivery | Inventario real respeta decisiones; recursos VM solo dev |
| 3 Reglas de ejecución | Primera iteración; 39 obligaciones; 44 límites de cambios/Git/despliegue | Status/diff propio, herramientas/arquitectura inspeccionadas y autorización aplicable |
| 4 Auditoría general | 39 marcos, SEC01–08, fronteras, hallazgos y excepciones | Hallazgos con evidencia real; controles de auth/permisos/datos probados |
| 5 Next.js | 39 SEC05; QA18/19, TypeScript/build web | Servidor/cliente, cookies/CSRF/CSP, rutas, caché y datos emitidos comprobados |
| 6 React Native | 39 SEC06; E2E nativo y release | SDK Expo real, Keychain/Keystore, links, permisos y builds iOS/Android verificados |
| 7 API/backend | Inventario 39 y 20; QA01–05/09 | Método/ruta/roles/entradas/salidas/límites reales; denegaciones directas probadas |
| 8 Pedidos/precios/pagos | 39 SEC04; QA06–13, transacciones/sandbox | Autoridad Go, idempotencia, Stripe auténtico, concurrencia, estados y QR probados |
| 9 Dependencias | 39 SEC08; gates SCA y supply chain | Inventario/locks/licencias, compatibilidad, govulncheck/auditoría/build reales |
| 10 Secretos | 39 SEC08; secret scanning y confianza Actions | Prevención/evidencia saneada; rotación autorizada y alcance si existe exposición |
| 11 Testing | Pirámide, matriz QA01–20, regresión/E2E/a11y; 44 decisión por cambio | Test nuevo/adaptado/existente ejecutado o sin test justificado; resultados reales |
| 12 Seguridad automatizada | Gates SAST/SCA/secretos/imagen/DAST | Scans aplicables reales, findings triageados y entorno dinámico autorizado |
| 13 Cobertura | Baseline/ramas/assertions por riesgo | Reportes auténticos y no reducción injustificada de módulos críticos |
| 14 GitHub Actions CI | Monorepo, comandos, gate always fail-closed y 44 | Ejecución del SHA exacto; faltantes/fallos/saltos inesperados bloquean |
| 15 GitHub Actions CD | Entornos separados; Actions/GHCR y 44 | Staging automático validado; aprobación manual de producción y mismo digest |
| 16 Quality gates | Clases obligatoria/informativa/periódica/manual | Fallos obligatorios bloquean; control ausente no produce falso verde |
| 17 Ramas y PR | main/protecciones/owners y disponibilidad pendientes | Reglas reales, revisiones y checks obligatorios; sin bypass/force-push |
| 18 Commits | Conventional Commits; 44 cierre por bloque coherente | Asunto/cuerpo específicos, alcance atómico y pruebas realmente ejecutadas |
| 19 Precommit | Status/diff/diff --check, propios, secretos y stage selectivo | Diff revisado, hooks correctos e inspección del commit final |
| 20 Push | Agente local commit/push por bloque; misma PR; 44 | Remoto/branch/base autorizados, push real y Actions del SHA exacto |
| 21 Code review | Corrección/seguridad/regresión/recursos/a11y/performance | Hallazgos relevantes corregidos; IA diferenciada de revisión humana |
| 22 Pull Requests | Problema/solución/pruebas/seguridad/CI/riesgos/deploy/rollback | Checklist auténtico, evidencia saneada y aprobación independiente según reglas |
| 23 Observabilidad | 41; 39 privacidad/incidentes; QA datos | Errores/latencia/auth/pedidos/pagos/servicios/DB/deploy con alertas y sin secretos |
| 24 Rendimiento/carga | Entorno autorizado, p50/p95/p99/recursos; 16 nativo | Mediciones reproducibles; 120 FPS solo release/dispositivo físico compatible |
| 25 Documentación | Política integrada en documentos del paquete | Enlaces/coherencia comprobados; guías útiles sin duplicados vacíos |
| 26 Roadmap | Fases A–G, alcance y pendientes | Cada fase entrega evidencia y bloques coherentes; fallo obligatorio impide cierre |
| 27 Informe por iteración | Esquema de resultados/estados; 44 trazabilidad | Tests/build/CI/Git/reviews/releases reales, pendientes y riesgos declarados |
| 28 Definición de terminado | Cierre técnico, merge y producción diferenciados; 44 | Implementación/revisión/tests/gates/SHA correctos; aprobaciones necesarias |
| 29 Ejecución de auditoría | Inspección disponible en 00; procedimiento inicial de este documento y 39 | Código/Git/accesos reales antes de auditar/implementar; ningún resultado simulado |

## 12. Pendientes y aceptación de la política

Pendientes: repositorio/remoto y propietarios reales; scripts/gestor/toolchains y baseline; cierre de contratos comerciales que condicionan tests; fixtures de PostgreSQL/PostGIS/Redis y sandboxes; visibilidad/plan/cuentas GitHub/GHCR; recursos/red/secretos del host y staging; comandos de gate reproducibles; estrategia de migración/restore/rollback; dispositivos y cuentas de firma Apple/Android. Expo continúa como decisión nativa actual: esta política no autoriza cambiar a Flutter ni sustituir 120 FPS físicos por una prueba web.

Antes de habilitar el pipeline, el responsable técnico y DevSecOps deben revisar el plan de jobs, scripts existentes, fuentes confiables, permisos, pruebas del bloqueo fail-closed y evidencia por SHA/digest. Antes de producción, operación revisa staging, migración, capacidad y recuperación; el responsable autorizado da aprobación manual del release concreto. Si una protección indispensable no está disponible por plan o acceso, dejar la entrega bloqueada hasta disponer de un mecanismo verificable equivalente; no saltarse la política.

La revisión documental v1.7 aplica security-best-practices y sus referencias Go/React/Next.js/JavaScript general. Son guías de política, no tests ni scans ejecutados. Los ejemplos de credenciales, sleeps, floats monetarios, teardown destructivo o actions @latest de una skill no prevalecen sobre Foodtrucks; no se copian. En esta actualización se han consultado las fuentes oficiales de GitHub sobre always y GHCR; las demás referencias enlazadas deben revalidarse por versión/plan al implementar.

## 13. Verificación futura de recursos UI y permisos v1.8

La ampliación [45](45-catalogo-21st-frontend.md), [46](46-panel-admin-negocios-suscripciones.md) y [47](47-novedades-onboarding-permisos.md) introduce especificaciones, no tests implementados. Mantener la evaluación de pruebas por cambio coherente de [44](44-politica-commits-ci-cd-tests.md).

| ID | Escenario a comprobar al existir código | Resultado exigido |
| --- | --- | --- |
| QA21 Novedades | Primera presentación relevante, varias novedades de la misma actualización, repetición/actualización menor, cambio rol/plataforma, cierre/Ahora no y consulta Perfil | Una presentación automática agrupada por actualización con identificador estable; cambiar de rol no repite una presentación consumida; contenido elegible real; reapertura manual; no interrumpir compra/pago/pedido/QR |
| QA22 Permisos | Concedido, denegado, temporal, revocado, canAskAgain false, regreso ajustes y permisos provisionales/capacidades push | Estado real releído; sin prompts insistentes/cadenas; alternativa manual/seguimiento; iOS/Android preavisos apropiados; no permisos extras en binario |
| QA23 Admin y fechas | Actor no admin/recurso ajeno, guardado/suspensión fallido, factura ausente, búsqueda/filtros/paginación y cambio concurrente | Go autoriza y audita; estados independientes; motivo/confirmación y pendiente/error persistentes; precios/pedidos no se alteran por UI |
| QA24 Recursos/tema/a11y | Ambos temas, responsive, keyboard/VoiceOver/TalkBack, texto grande, imágenes ausentes, largo contenido, rango de fechas/zona horaria | Controles/acción accesibles, filtro observable, header web/dock solo nativo, indicador anunciado y movimiento reducido; licencia/runtime/source revisados |

Fechas: probar límites del rango y cambios de mes/año/hora en la zona operativa configurada, sin inferir reservas. Formularios preservan borrador/error al fallar; tarjetas de precio/movimientos no aceptan valores de demo como autoridad. Cámara solo escáner comerciante; mostrar QR cliente no pide permiso. Selector de imágenes no obliga a biblioteca completa/audio. Tests JS no acreditan solicitudes reales del SO o rendimiento de dispositivo.

En esta entrega solo se comprueba documentación, enlaces, imágenes originales y paquete; permisos, UI, backend, licencias pendientes, SDK, tests de comportamiento, CI y builds permanecen NO VERIFICADO.

## 14. Verificación futura de protección de datos y gobernanza — v1.9

Relacionar la [política de protección de datos](48-proteccion-datos-gobernanza.md) con requisitos propios y casos observables. La decisión de añadir/adaptar/ejecutar pruebas sigue [44](44-politica-commits-ci-cd-tests.md); no generar tests por cada referencia normativa ni un segundo gate de aceptación.

| ID | Escenario futuro con datos sintéticos | Resultado exigido |
| --- | --- | --- |
| QA25 Exportación | Cuenta propia, usuario ajeno, soporte sin permiso y enlace expirado/reutilizado | Autenticación y autorización por alcance; salida mínima sin datos de otro cliente/negocio ni secretos; entrega con visibilidad/plazo controlados |
| QA26 Supresión/restricción | Solicitud aprobada, repetida y concurrente; DB, Redis, medios, colas y proveedores pertinentes | Estado consistente e idempotente; accesos/información pública invalidados; conservación aprobada separada y restringida; resultado externo incierto no se declara completado |
| QA27 Recuperación | Backup anterior a una supresión/retirada, restauración aislada y outbox antigua | Reaplicar decisiones posteriores antes de abrir acceso/reactivar workers; datos suprimidos no vuelven a servirse ni generan envíos/exportaciones; conciliar efectos económicos |
| QA28 Telemetría | PII/tokens/QR señuelo en errores, URLs, logs, trazas, breadcrumbs, reportes y artifacts CI | Filtrado antes de salida, acceso limitado y retención aplicable; evidencia saneada; no dashboards públicos ni datos privados en labels |
| QA29 Consentimiento | Rechazo/retirada antes del arranque, después de enqueue, tras reinicio/restauración y fallo del proveedor | Ninguna recogida/exportación no permitida; no replay histórico; compra/QR operativos; retirada y solicitud de supresión siguen procedimientos distintos |

Probar comportamiento real en la capa más útil: contratos/componentes para entradas y estados, integración PostgreSQL/PostGIS/Redis/medios para efectos y tests controlados de proveedores cuando proceda. No usar datos live ni asumir que un fake demuestra una eliminación externa. Registrar requisito, caso, comando, resultado, SHA/entorno, responsable y limitaciones; bases, plazos y conservación pendientes no se inventan para completar assertions. Los casos QA25–29 no están implementados ni ejecutados en este paquete documental.
