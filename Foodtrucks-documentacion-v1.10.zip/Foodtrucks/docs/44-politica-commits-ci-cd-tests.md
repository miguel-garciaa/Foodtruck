# Política de commits, pruebas y CI/CD

**Versión:** 1.9 · **Fecha:** 14 de octubre de 2026. **Estado:** política documentada; implementación y ejecución de pipelines **NO VERIFICADO**, porque esta carpeta no contiene aplicación, Git/remoto, workflows ni acceso a los entornos. Las obligaciones siguientes se aplican al incorporar código real. No acreditan un pipeline funcional hoy.

## 1. Objetivo, decisiones y autoridad

Cada cambio debe ser trazable desde su requisito y pruebas hasta el commit, la ejecución de CI y el artefacto desplegado. Seguridad y fiabilidad primero; usar herramientas y controles proporcionales a Foodtrucks.

El usuario confirma commit y push tras cada **cambio coherente**, GitHub Actions, GHCR, staging automático y producción con aprobación manual. El destino de DEV/PROD sigue siendo el servidor doméstico; la VM de 4 vCPU/8 GB/40 GB es de desarrollo y no dimensiona producción. Web Next.js, móvil React Native + Expo + TypeScript, backend Go/Chi/pgx/sqlc, PostgreSQL/PostGIS y Redis. Mantener Google y Apple, Mapbox, Compose/Caddy, fotos locales y backups externos. No introducir Flutter, Supabase, S3, Kubernetes, Jenkins o Terraform para completar este ciclo.

La autorización de commit/push cubre cambios solicitados en una rama de trabajo propia. No concede merge, push directo a la rama protegida, force-push, cargos reales, envío de mensajes a terceros, despliegue productivo ni publicación en tiendas. Producción exige aprobación explícita de la versión concreta.

Los textos aportados por el usuario se integran como requisitos de las políticas, sin archivos que reproduzcan los prompts. [Decisiones](23-decisiones-pendientes.md), [entornos](21-entornos-ci-cd.md), [QA](40-testing-qa-github.md), [seguridad](39-seguridad-devsecops.md), [observabilidad](41-observabilidad-grafana-prometheus-sentry.md) y [guía DevOps](devops/README.md) completan esta política.

## 2. Auditoría antes de implementar CI

Inspeccionar README/AGENTS, estado Git, rama/remotos y cambios ajenos; manifests, lockfiles y versiones; módulos Go y workspaces; Dockerfiles/Compose/Caddy; SQL/migraciones; tests/scripts; workflows; variables y gestión de secretos; despliegue y rollback existentes. Registrar nombres y metadatos saneados, sin imprimir .env o valores sensibles.

El diagnóstico debe separar componentes existentes, ausentes, fallos previos, riesgos y orden de trabajo. Ejecutar una referencia inicial de los checks disponibles. Conservar configuraciones válidas. No crear endpoints, módulos, versiones, contenedores o comandos ficticios para demostrar cobertura del plan.

Si un componente está ausente, documentar qué falta. Si existe pero no tiene el test o comando necesario, crear lo pertinente dentro del alcance o registrar el bloqueo: no tratarlo como éxito. La cobertura y los presupuestos de rendimiento se fijan después de medir una referencia reproducible.

## 3. Ciclo obligatorio de cada cambio coherente

1. Definir un resultado revisable: funcionalidad, corrección, configuración, documentación o una parte completa de un hito. No equivale a cada guardado, línea o mensaje.
2. Implementar el bloque junto con contratos/documentación y evaluar impacto en pruebas. Mantener fuera cambios ajenos, datos privados y archivos generados no necesarios.
3. Ejecutar formato, lint, análisis, tests y build aplicables; revisar diff, permisos, secretos y efectos. Corregir fallos del cambio antes del commit de entrega. Un bloqueo externo se informa, sin declarar terminado el componente.
4. Preparar únicamente archivos propios y crear un commit atómico y explicativo. Ejemplos de formato: `feat(orders): validate server prices`, `fix(auth): reject revoked sessions`, `test(payments): cover duplicate events`, `ci: require current commit checks`. Son ejemplos, no commits realizados.
5. Con remoto y autenticación disponibles, hacer push de la rama de trabajo después del bloque. Abrir o actualizar una PR por tarea cuando corresponda. No volver a pedir la autorización ya otorgada para este ciclo.
6. Registrar el SHA y observar sus checks. Si CI falla, reproducir, corregir y publicar otro commit coherente. No declarar terminado con una ejecución antigua, cancelada, pendiente o sin evidencia.
7. Entregar resumen de archivos, pruebas locales/CI, SHA, PR si existe, limitaciones y pendientes. Si no hay Git/acceso, entregar los archivos y marcar commit/push/CI **NO VERIFICADO**, con la causa y pasos necesarios.

Prohibidos commits vacíos para fingir progreso, `[skip ci]`, desactivar hooks/checks, rebajar assertions o usar force-push para ocultar fallos. El agente/editor realiza Git con autenticación propia fuera de CI; el pipeline no debe modificar código y producir un bucle de autocommits. La propagación de eventos con tokens depende del contexto: [GitHub: activar workflows](https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/trigger-a-workflow).

## 4. Evaluación de pruebas por cambio

Registrar en la PR o entrega local el comportamiento/riesgo, comprobación, resultado y una de estas categorías:

| Categoría | Cuándo corresponde | Evidencia mínima |
| --- | --- | --- |
| Nueva | Comportamiento nuevo, regresión o riesgo sin cobertura | Test que distingue resultado válido e inválido; falla ante el defecto cuando sea practicable |
| Adaptada | Cambia un contrato, regla, interfaz o escenario existente | Assertions actualizadas por la nueva especificación y ejecución |
| Existente ejecutada | La suite ya demuestra el comportamiento afectado | Tests identificados y resultados actuales; no basta afirmar que existen |
| No necesaria, justificada | Texto estático o cambio sin comportamiento/riesgo nuevo | Motivo concreto y comprobación apropiada: enlaces, build, visual, formato o configuración |

Una sección nueva con acciones, permisos, datos, formularios o estados de error requiere evaluación y pruebas pertinentes. No crear tests artificiales de literalidad por cada párrafo, ni snapshots gigantes o comprobaciones que repiten la implementación.

Una corrección importante debe tener regresión. APIs: inputs, permisos, ausencias, límites y errores externos. Datos: constraints, transacciones y concurrencia real. UI: interacción, carga/error, accesibilidad, ambos temas, header web y dock solo nativo. Los contratos/lockfiles/configuración compartidos amplían la selección a sus consumidores. Matriz detallada en [QA](40-testing-qa-github.md).

## 5. Arquitectura y eventos de GitHub Actions

La siguiente es una **especificación de implementación**, no una relación de archivos ya creados. Empezar con un coordinador CI, jobs por componente y gate final. Separar workflows de release/despliegue; extraer reusable workflows o composite actions cuando reduzcan duplicación real.

| Responsabilidad futura | Eventos y condiciones | Resultado |
| --- | --- | --- |
| CI coordinada: Go, web, móvil, documentación y seguridad aplicable | Push a ramas de trabajo/integración; PR a rama protegida; manual | Evidencia por SHA, selección de componentes y `ci-gate` estable |
| Reusable por componente, si aporta valor | `workflow_call` desde coordinador; entradas y secretos explícitos | Contrato de checks sin duplicar activaciones |
| Seguridad periódica/Dependabot | Programación acotada y manual; cambios de dependencias en CI | Informe y gestión de hallazgos, sin acceso a producción |
| Construcción y publicación GHCR | Commit integrado de rama protegida después de CI; release/manual confiable | Imágenes escaneadas y digests asociados al commit |
| Staging | Artefacto aprobado del commit integrado | Migración compatible, smoke y estado del despliegue |
| Producción | Promoción manual de una release probada en staging | Mismo digest, aprobación, registro y verificaciones |
| Release móvil | Manual/tag autorizado; fuentes y CI aprobadas | Build/distribución según credenciales y política de tiendas |
| Rendimiento extendido | Manual o calendario en staging aislado | Comparación contra referencia y reporte de recursos |

No añadir `develop` por suposición. Base propuesta: rama principal protegida, feature/fix y PR, staging tras integración y releases identificables. Adaptar nombres al Git real; mantener `develop` si existe y tiene una función aprobada. Exigir revisión y checks en la protección; CODEOWNERS solo si existen responsables y aporta valor. Merge queue, si se adopta, requiere comprobar sus eventos específicos.

Los reusable workflows van directamente en `.github/workflows`; GitHub no admite el subdirectorio `workflows/reusable/`. Las composite actions pueden usar su propia carpeta de actions. [GitHub: reutilización](https://docs.github.com/en/actions/how-tos/reuse-automations/reuse-workflows).

Cancelar CI redundante por rama/PR, con grupos distintos para push y PR si prueban revisiones distintas. No cancelar despliegues o migraciones a mitad de ejecución. Poner timeouts y retención de artifacts/cachés explícitos, basados en duración y consumo observados. No guardar secretos, sesiones, HAR privados o dumps en artifacts/cachés.

## 6. Gate obligatorio y revisión exacta

El workflow coordinador se activa para todas las PR/push relevantes. Aplicar filtros a los jobs, no suprimir el workflow requerido por rutas: un cambio solo documental también obtiene una evaluación final. Cambios en selección/gates/tooling se comprueban expresamente.

`ci-gate` debe ejecutarse al finalizar el grafo incluso si una dependencia falla, mediante la condición apropiada, y evaluar estados y selección esperada. En cancelación total puede no llegar a ejecutarse: nunca permite integrar. No puede depender de outputs vacíos que transformen un fallo del detector de cambios en «ningún componente afectado». [GitHub: dependencias entre jobs](https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-jobs).

| Situación | Decisión del gate |
| --- | --- |
| Detector correcto y todos los checks obligatorios seleccionados con éxito | Aprobar esa revisión |
| Fallo de test/build/seguridad/setup o falta de comando obligatorio | Bloquear |
| Job esperado ausente, cancelado o saltado inesperadamente | Bloquear |
| Job no afectado, salto justificado por selección comprobada | Admitir como no aplicable |
| Componente realmente inexistente | Documentar ausencia; no acreditar funcionalidad |
| Checks verdes de SHA anterior o PR basada en integración obsoleta | Exigir nueva comprobación según protección de rama |
| PR externa necesita credencial privada para una prueba | Registrar limitación; separar prueba confiable requerida antes de release, sin dar el secreto al fork |

Registrar head SHA, base y revisión de integración de PR. Push comprueba la rama; PR comprueba su integración con la base según configuración; el push del commit realmente integrado se valida de nuevo antes de construir la release. No reutilizar el resultado de la rama para un commit integrado distinto. [GitHub: eventos](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows), [checks requeridos](https://docs.github.com/en/pull-requests/how-tos/merge-and-close-pull-requests/troubleshooting-required-status-checks).

`continue-on-error` no oculta controles críticos. Una excepción de seguridad necesita alcance, justificación, responsable, vencimiento y seguimiento; no una allowlist global. Umbrales progresivos de cobertura, carga y tamaño se definen con mediciones y riesgo, sin porcentajes inventados para dar CI verde.

## 7. Controles por componente y seguridad

| Área | Controles exigibles cuando exista implementación |
| --- | --- |
| Go | gofmt sin diferencias, vet, verificación de módulos, build, unitarios/HTTP/contratos; race; integración SQL/PostGIS/Redis cuando afectada; fuzzing acotado; cobertura total/paquete; govulncheck |
| Negocio | Precio autoritativo entero, stock/concurrencia, idempotencia, webhook firmado/deduplicado, auth/permisos entre usuarios/vendedores, transiciones y QR único; reglas comerciales pendientes no se inventan |
| Next.js | Lockfile congelado, TypeScript/lint/formato, componentes/integración, build, E2E crítico y accesibilidad; temas y navegación; auditoría de dependencias |
| React Native/Expo | Scripts y SDK reales; tests JS/componentes, Android debug y tooling nativo; iOS compilación en macOS; firmas/releases en contexto protegido; no migrar framework ni suponer que test JS prueba nativo |
| Supply chain | Detector de secretos como Gitleaks; Dependabot y SCA; SAST con gosec/CodeQL según cobertura y disponibilidad; evitar herramientas redundantes |
| Docker | Dockerfile/ignore, multietapa/no root, bases y dependencias fijadas, sin secretos; scanner como Trivy; SBOM si útil; scan del artefacto exacto antes de desplegar |
| Rendimiento | Benchmarks/allocs rápidos reproducibles; k6 acotado en staging y pprof privado cuando útil; p95/p99, errores y recursos; no carga intensiva en producción |

Las selecciones auxiliares se implementan tras auditar versiones, licencia, elegibilidad y coste. No se han instalado los scanners ni runtimes por esta política. Fuentes: [Go testing](https://pkg.go.dev/testing), [govulncheck](https://go.dev/doc/security/), [CodeQL](https://docs.github.com/en/code-security/code-scanning), [Expo tests](https://docs.expo.dev/develop/unit-testing/), [Playwright](https://playwright.dev/docs/best-practices).

CI usa datos sintéticos, PostgreSQL/PostGIS y Redis aislados; Stripe test/fixtures/fakes, correo sink/fake, push fake y anuncios/analítica live desactivados. Las pruebas con proveedor necesitan contexto confiable y cuentas de prueba propias. No cargos reales, conversiones live, emails o push a usuarios. 120 FPS, cámara, Mapbox, OAuth, avisos del SO y accesibilidad nativa requieren validación específica en dispositivos físicos/release.

PR externas no reciben secretos de producción, publicación, firma o proveedores privados ni acceso a la LAN doméstica. No ejecutar su código mediante `pull_request_target` u otro contexto privilegiado. Si hay runner propio de despliegue, limitarlo a código y jobs confiables, separado de pruebas de PR y datos de producción. Docker socket equivale a una capacidad privilegiada y no se comparte con código arbitrario.

## 8. GHCR, artefactos y promoción

Construir desde la revisión integrada validada, con fuentes/toolchain/lockfiles identificados. Publicar en GHCR después del escaneo obligatorio. Tags de versión y SHA facilitan identificación; la referencia de despliegue es el digest. `latest` no es una referencia suficiente.

Guardar un registro de release con commit, ejecución de CI/build, imágenes y digests por servicio, versión de migraciones, configuración no secreta versionada, fecha, resultado de staging y anterior release estable. SBOM/reportes, si existen, deben corresponder a esas imágenes. Este registro es un contrato operativo propuesto, no una nueva API de negocio ni un archivo ya implementado.

Producción promueve las mismas imágenes por digest probadas en staging, con su configuración independiente; no reconstruye el código durante la promoción. «Reproducible» exige entradas controladas y trazabilidad; no afirmar identidad binaria entre builds independientes sin demostrarla.

Permiso `packages: write` solo en publicación confiable; lectura mínima para despliegue. Confirmar propiedad/visibilidad del paquete, vinculación al repo y credencial de lectura compatible con GHCR sin copiar el token efímero del job al servidor como credencial permanente. [GitHub: GHCR](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry).

## 9. Despliegue, migraciones y rollback

```mermaid
flowchart LR
  A[Cambio coherente y pruebas] --> B[Commit y push a rama]
  B --> C[CI del push y de la PR]
  C --> D[Revision e integracion autorizada]
  D --> E[CI del commit integrado]
  E --> F[Build y escaneo]
  F --> G[GHCR y registro de digests]
  G --> H[Staging automatico y smoke]
  H --> I[Aprobacion manual de release]
  I --> J[Produccion con los mismos digests]
  J --> K[Health y observabilidad]
  K --> L[Rollback compatible si falla]
```

El mecanismo de acceso al servidor doméstico sigue pendiente de WAN/CGNAT/administración y recursos reales: SSH restringido con host verificado o despliegue saliente/pull controlado. No abrir SSH público ni instalar un runner con acceso productivo como consecuencia automática de elegir GitHub Actions. [Servidor doméstico](38-servidor-domestico.md).

Staging: comprobar artefacto/origen, configuración/separación de entorno, conectividad, capacidad/disco y backups necesarios; ejecutar una vez las migraciones compatibles; actualizar Compose; verificar readiness, DB/Redis y recorridos smoke sobre rutas reales; registrar resultado. El éxito habilita la promoción, no despliega producción por sí solo.

Producción: aprobar release/digests concretos, verificar compatibilidad API con apps antiguas y esquema, asegurar acceso/copia previa ante cambio sensible; aplicar migración controlada y servicios; ejecutar health/smoke y observar errores/latencia/reinicios. Registrar responsable, commit, digests, fecha y resultado. Separar notificación ordinaria CI de alerta de disponibilidad/seguridad.

Usar GitHub Environments y protecciones disponibles tras verificar plan/visibilidad. Si revisores obligatorios no están disponibles, la promoción se realiza mediante un procedimiento manual restringido al operador autorizado, con evidencia de aprobación y release exacta; nunca sustituir el control por un secreto accesible a cualquier workflow. La disponibilidad de protecciones depende del plan y del tipo de repo. [GitHub: entornos](https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments).

Migraciones: versionadas, probadas desde base vacía y esquema previo sobre DB desechables; límites de locks y expand-contract según cambio. Backups externos antes de cambios sensibles y restore probado. No ejecutar cambios destructivos automáticamente. No usar el rollback de código como reversión del esquema.

Rollback: detener nuevas promociones, identificar release estable, comprobar esquema/datos y recuperar digests anteriores si compatible; verificar health/smoke, registrar incidente y notificar por canal autorizado. Si hubo cambio incompatible, decidir corrección hacia delante o recuperación explícita de datos; no ejecutar down migrations/restore destructivo a ciegas. Conservar fotos/DB/volúmenes al cambiar imágenes.

La exclusión de despliegues debe cubrir workflows manuales/automáticos/rollback del mismo entorno. Concurrency de Actions evita solapamientos allí; bloqueo adicional en el host evita carreras con intervenciones locales. No cancelar una migración iniciada para dar prioridad a un push nuevo. No ejecutar carga intensiva o efectos externos live durante smoke/restore.

## 10. Secretos, responsabilidades y mantenimiento

| Rol operativo por asignar | Responsabilidad |
| --- | --- |
| Autor/agente | Cambio coherente, pruebas, documentación, commit/push autorizados y evidencia |
| Revisor | Contratos, test adecuado, permisos, riesgo de migración y aprobación de integración |
| Administrador GitHub | Reglas/protecciones, responsables, Actions, Environments, permisos y rotación |
| Operador de despliegue | Aprobar producción, verificar release/backup/capacidad, ejecutar y registrar recuperación |
| Responsable de seguridad/incidentes | Triage de hallazgos/excepciones y respuesta con fecha/seguimiento |

Son funciones propuestas, sin personas o revisiones humanas inventadas; pueden recaer en la misma persona a esta escala. Registrar quién tiene cada permiso y limitar credenciales a entorno y propósito.

Inventariar GitHub Secrets/vars y configuración privada del host sin valores: Stripe test/live/webhook, SQL/Redis, Resend, Mapbox, OAuth Google/Apple, Sentry, firma móvil y mecanismo de despliegue. No todos pertenecen a CI. La configuración runtime permanece en el entorno servidor; PR rápidas no necesitan secretos live. `.env.example`, cuando se implemente, contendrá solo nombres y valores ficticios compatibles con el código real. La [guía DevOps](devops/README.md) asigna ubicación/privilegios propuestos y pasos de validación.

Fijar Actions externas a SHA completos comprobados en sus repositorios; registrar versión legible, actualizar mediante PR y ejecutar los checks antes de aprobar. Revisar cambios de permisos y código upstream. Fijar scanners/toolchains por versión verificada y lockfiles; no pegar SHAs supuestos o instalar `latest` en releases. Revisar periódicamente dependencias, excepciones, credenciales, retención/costes y pruebas intermitentes. No asumir Actions/macOS/EAS/Sentry/GHCR sin coste; registrar consumo y límites en [presupuesto](37-costes-presupuesto.md).

## 11. Implantación por fases y evidencia de aceptación

| Fase | Entrega en el repositorio real | Evidencia antes de cerrarla |
| --- | --- | --- |
| 1 Auditoría | Inventario, baseline y decisiones de adaptación | Archivos/versiones y checks reales; ausencias identificadas |
| 2 CI básica | Formato/lint/tipos/tests/build y gate | Workflow válido; éxito y fallo intencional controlado del gate |
| 3 Seguridad | SCA/SAST/secret scanning y permisos | Hallazgos triageados, PR externa sin secretos, excepción controlada |
| 4 Testing avanzado | SQL/Redis/concurrencia/fuzz y rendimiento pertinente | Aislamiento probado y referencia reproducible |
| 5 Docker/GHCR | Imágenes mínimas, scanner, digests y registro | Build/publicación autorizada y lectura de artefacto verificado |
| 6 Staging | Migración compatible, Compose y smoke automáticos | Despliegue y fallo controlado sobre entorno propio |
| 7 Producción | Promoción manual y rollback compatible | Aprobación/restricción demostrada; producción real solo autorizada |
| 8 Observabilidad | Release/errores/métricas/alertas correlacionados | Alertas de prueba recibidas por destinatario autorizado y saneamiento |
| 9 Validación | Manual, permisos, recuperación y resultados finales | Recorrido completo trazable, pendientes y límites explícitos |

Fase cerrada exige checks disponibles ejecutados, errores corregidos, diff revisado y documentación actualizada; commit/push por bloque si el repo lo permite. No añadir un archivo vacío por cada fase.

### Cobertura de requisitos de CI/CD

La tabla resume qué política atiende cada área solicitada; **cobertura documental no significa ejecución**.

| Área del requisito | Política / evidencia exigida |
| --- | --- |
| 1 Contexto | §1–2; stack/recursos/aislamiento reales |
| 2 Auditoría | §2; inventario y baseline |
| 3 Workflows | §5–6; eventos, selección, gate y SHA |
| 4 Ramas/PR | §3/5; historial, revisión y protección |
| 5 Go | §4/7 y QA; tests/build/race/cobertura |
| 6 Negocio Foodtrucks | §7 y QA; pagos, permisos, stock y QR |
| 7 DevSecOps | §6–7/10 y seguridad; scans/excepciones/secretos |
| 8 Rendimiento | §7 y QA/rendimiento; referencia y carga controlada |
| 9 Web | §7 y QA; Next.js/E2E/temas/header |
| 10 Móvil | §7/9 y QA; SDK real, builds, firmas y dispositivos |
| 11 Docker/GHCR | §8; scan y digest del artefacto |
| 12 Despliegues | §9; staging automático y producción aprobada |
| 13 Migraciones | §9 y datos/backups; compatibilidad/restore |
| 14 Rollback | §9; anterior estable, esquema y verificación |
| 15 Observabilidad | §9 y observabilidad; release/alerta y métricas |
| 16 Secretos | §7/10 y guía DevOps; ubicación, permisos y rotación |
| 17 Documentación | Guía DevOps y documentos enlazados; operación/local/fallos/glosario |
| 18 Aceptación | §6/11; resultado verificable y no éxito por omisión |
| 19 Fases | Tabla de implantación; bloques y evidencias |
| 20 Entrega final | Registro siguiente A–J; mediciones/IDs reales |

Entrega de implementación A–J: **A** diagrama/flujo; **B** workflows reales y eventos; **C** pruebas/resultados/cobertura/pendientes; **D** seguridad/hallazgos/controles; **E** benchmarks/carga/límites; **F** imágenes/digests/despliegue; **G** rollback probado o limitación; **H** commits/SHAs; **I** secretos/permisos/configuración pendiente; **J** mantenimiento/diagnóstico. No rellenar campos con valores inventados.

## 12. Estado actual y cómo completar la validación

| Elemento | Estado de esta entrega |
| --- | --- |
| Política, decisiones y guía | Documentado en Markdown |
| Integridad/enlaces/ZIP | Comprobación documental; ver resultado de la entrega |
| Workflows/scripts/app/tests/cobertura | NO VERIFICADO: no existen en la carpeta accesible |
| Commits/push/PR/protecciones/Environments | NO VERIFICADO: sin Git/remoto/acceso al proyecto |
| Imágenes/GHCR/build nativa | NO VERIFICADO: sin fuentes/configuración/credenciales |
| Staging/producción/migración/rollback/alertas | NO VERIFICADO: sin aplicación ni entornos disponibles |

Para validar después: aportar/abrir el repositorio real, ejecutar la auditoría §2, fijar versiones/scripts y configurar permisos/secretos por entorno; implementar por las fases; probar CI positiva y negativa, publicación y staging; ensayar migración/rollback/alerta en entorno aislado; aprobar una release concreta antes de producción. Guardar comandos, run IDs, SHAs, digests, mediciones y resultados reales. Los comandos de ejecución exactos se documentan desde ese repo, sin suponer sus endpoints o archivos.

## 13. Trazabilidad de privacidad y calidad — v1.9

Antes de un cambio que afecte datos personales, evaluar finalidad, accesos, conservación, destinatarios y efectos de borrado/restore conforme a [48](48-proteccion-datos-gobernanza.md). Vincular el requisito y riesgo al control existente, prueba/evidencia, SHA/release, responsable y estado; una ficha de cambio puede reutilizar esta evidencia sin otro formulario por cada marco.

Código asistido por IA pasa el mismo gate vigente: revisión, pruebas pertinentes, commit/push y checks del SHA exacto. No usar datos personales reales ni secretos en prompts/fixtures/reportes por la mera autorización de escribir código. Mantener excepciones justificadas, con propietario/vencimiento y riesgo residual; ninguna certificación, cobertura o control efectivo se presume de la documentación. No modificar el flujo de aprobación productiva acordado ni añadir autocommits en CI por esta ampliación.
