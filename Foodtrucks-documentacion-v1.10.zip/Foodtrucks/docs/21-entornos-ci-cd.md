# Entornos y CI/CD en GitHub

**Cerrado:** código/documentación en GitHub; GitHub Actions; GHCR; commit/push por cambio coherente; staging automático y producción con aprobación manual. **Estado:** política documentada, implementación NO VERIFICADO; no hay Git/remoto, aplicación o workflows en esta carpeta. La [política operativa](44-politica-commits-ci-cd-tests.md) es la referencia para cambios/gates/promoción y la [guía DevOps](devops/README.md) organiza los procedimientos.

## Entornos

| Entorno | Uso y aislamiento |
| --- | --- |
| Local/VMware | Datos ficticios, Stripe test, frontend en ordenador |
| CI | DB/PostGIS y Redis efímeros; sin datos de usuarios |
| Staging/piloto | Despliegue automático de artefacto integrado validado, entorno aislado del servidor doméstico PROD; recursos/acceso por definir |
| Producción doméstica | Promoción manual aprobada del mismo digest probado; claves live/datos reales y acceso restringido |

Separar bases, volúmenes, dominios, Mapbox/config pública, clientes OAuth, dispositivos push, IDs de app y secretos Stripe/Resend/Cloudflare por entorno. Ningún backup de producción se restaura sin desactivar efectos externos.

Versiones de Go/Node/Expo/React Native/Next.js/DB/Redis y PostGIS se fijan tras verificar compatibilidad. No asumir latest como configuración reproducible.

## Pull requests

Base propuesta de ramas: principal protegida y cambios por PR, con revisión proporcional; adaptar a Git real sin crear develop por suposición. La política ya exige cambios coherentes, evaluación de tests y seguimiento de checks del SHA vigente. El coordinador CI debe emitir un gate obligatorio aun en cambios documentales y evaluar jobs esperados; falla/cancelación/setup fallido/salto inesperado bloquean. Tests/lint/build relevantes para rutas y consumidores afectados, sin saltar comprobaciones por comodidad.

Para backend, cuando exista módulo y herramientas:

~~~bash
go test ./...
go test -race ./...
go vet ./...
go build ./cmd/api
go build ./cmd/worker
~~~

Comprobar formato gofmt, regeneración sqlc sin diferencias inesperadas e integración real PostgreSQL/PostGIS. Estos comandos se ejecutarán dentro de backend/ y no han sido ejecutados aquí, porque no existe código.

Frontend: definir scripts lint, typecheck, test y build en cada workspace; ejecutar el gestor finalmente elegido con instalación congelada del lockfile. No afirmar que npm run build funciona antes de existir package.json/scripts.

CI no acredita 120 FPS ni Live Activities: requieren build nativa/dispositivo. Verificar Expo, compilar development/release builds y probar rutas nativas antes de distribución.

## Seguridad de Actions

Permisos mínimos por job, secretos por entorno y acciones/dependencias fijadas y revisadas. PR no confiable no recibe credenciales de despliegue. No ejecutar código de fork con secretos mediante un workflow privilegiado. [Guía GitHub](https://docs.github.com/en/actions/reference/security/secure-use).

Evitar runner persistente en el servidor doméstico/PROD para PR arbitrarios. Si se adopta runner propio, aislamiento y confianza deben diseñarse primero. Firmas/credenciales de tienda fuera del repo; no imprimir env completos.

## Política de despliegue documentada

1. Ejecutar comprobaciones y producir imágenes desde commit identificado.
2. Escanear y publicar imágenes aprobadas en GHCR, sin secretos embebidos; registrar digest y commit integrado validado.
3. Preparar release con digests y configuración separada; staging automático valida el artefacto y producción promueve los mismos digests tras aprobación manual.
4. Verificar backup y estrategia de migración compatible.
5. Ejecutar migraciones controladas una vez, no en cada réplica sin coordinación.
6. Sustituir servicios de aplicación y worker mediante Compose.
7. Confirmar health/readiness y un smoke test sin cobros reales.
8. Registrar commit, migración, imagen, resultado y responsable.

SSH con clave limitada/verificación del host o alternativa segura pendiente. No usar StrictHostKeyChecking=no. Staging automático y aprobación manual de producción ya están confirmados. Verificar Environments/protecciones según plan o aplicar promoción manual restringida; el mecanismo concreto de acceso al domicilio sigue pendiente.

## Rollback y tiendas

Volver a imagen anterior cuando el esquema siga compatible. Rollback de código no deshace una migración destructiva ni un pago. Cambios de datos requieren estrategia por fases/restore explícito.

Móvil se distribuye por tiendas/builds, independiente de Compose. API debe mantener compatibilidad con versiones móviles anteriores. EAS, firma, cuentas Apple/Google y política OTA pendientes; cambios nativos requieren build apropiada, no actualización JS que los invente.

## Criterio verificable

Registrar checks realmente ejecutados y fallos. Despliegue solo se considera terminado tras observar servicio y flujo esperado; este paquete contiene el procedimiento, no una ejecución.

## Verificación de fidelización

Añadir pruebas de eventos repetidos, doble suscripción, dos canjes concurrentes, expiración/reserva/pago tardío, devolución parcial y financiación del descuento. Verificar cálculo entero, regla versionada y conciliación de ledger/proyección.

Si se decide cobro nativo, probar verificación de transacciones, notificaciones y restauración de derechos en sandboxes reales de tienda. No reutilizar datos/clientes/beneficios live en CI. Este paquete no ejecuta estos tests porque no contiene implementación.

## Preparación de medición publicitaria

Antes de conectar herramientas de publicidad, definir eventos, consentimiento y entornos. Comprobar deduplicación de compra/alta comercial, ausencia de datos personales/tokens en URLs/eventos y bloqueo de emisiones live desde desarrollo/CI.

Una prueba de etiqueta en navegador no demuestra que la venta esté confirmada: mantener autoridad Go/Stripe y conciliación. Herramientas de medición y política de atribución aún pendientes. [Marketing](27-marketing-google-ads.md).

## Dominio y correo por entorno

Cloudflare Registrar es común al dominio, pero hostnames, reglas y destinos de staging se separan de producción. No apuntar una preview arbitraria al dominio live. DNS/cambios de seguridad mediante cuenta/token mínimo, export de configuración y diff revisable; automatización futura no necesita un token global ni una clave en cada job. Emisión/renovación TLS debe funcionar con las reglas de origen definitivas.

Resend: desarrollo/CI usan fake/sink y pruebas HTTP simuladas; staging, si envía, utiliza remitente/clave separados y allowlist de destinatarios de prueba. No asumir que existe un sandbox completo que impida enviar a personas reales. Las entregas se etiquetan por entorno y los webhooks se asocian al secreto correspondiente.

Añadir tests de firma/replay, duplicados/fuera de orden, rebote/queja, baja, timeout/reintento, ventana idempotente y enlace expirado/visitado por escáner. Verificar que una outbox restaurada no pueda enviar antes de revisar su estado. Con cuentas y aplicación disponibles, ejecutar DNS/TLS, API nativa sin challenges, un webhook firmado y entrega real a una cuenta de prueba/relay Apple. [Cloudflare](29-cloudflare-dominio-dns.md), [Resend](30-correo-resend.md).

## Comprobaciones de marketing antes de release

U08 incorpora verificaciones de rutas públicas/privadas, metadata/canonical, sitemap/robots, JSON-LD y slugs/HTTP con datos de prueba. Probar que no se indexan/exponen privados, que contenido obsoleto se invalida y que Cloudflare no desafía verificadores autorizados. Los ejemplos documentales no prueban la salida HTML real.

GA4/Firebase, scripts publicitarios y SDK se habilitan solo por entorno/configuración explícita. Desarrollo/CI no envían conversiones ni usan inventario live; AdMob usa TestIds autorizados y builds apropiadas. Validar eventos duplicados/desordenados, rechazo/retirada de consentimiento desde arranque, PII/URLs, SDK inicializados y ad blocker/error sin bloquear compra.

Antes de publicación/campaña: ASO/links reales, cuentas/IDs, revisión de SDK y políticas, medición conciliada y autorización. El pipeline no publica ni activa por un calendario de 90 días. [SEO](32-seo-local-nextjs.md), [editores](33-monetizacion-adsense-admob.md), [medición](34-analitica-consentimiento.md).

## Seguridad/QA y observabilidad de release

U10 concreta gates, tests y flujo Git/PR en [testing/QA](40-testing-qa-github.md); U11 añade [observabilidad](41-observabilidad-grafana-prometheus-sentry.md). Reutilizar CI válida cuando exista, en lugar de crear todos los workflows de ejemplo. Fixtures/DB y efectos externos aislados; validación de reglas Prometheus, dashboards/provisioning, secretos y versiones junto a pruebas relevantes.

Release identificada con commit/artifact verificable y Sentry source maps/símbolos correspondientes cuando se adopten; tokens privados solo en el job necesario. Tests sintéticos y medición no generan pagos, anuncios, emails o push live en CI. Staging en entorno separado del doméstico PROD; confirmar acceso/aislamiento antes de usar un runner propio. Producción requiere aprobación manual de la release; un rollback automático solo procede si se configura y verifica su seguridad/compatibilidad dentro del alcance autorizado. No existe Git/CI/aplicación en esta carpeta para ejecutar esos procedimientos ahora.

## Verificación de la política v1.7

Push de rama, integración de PR y commit realmente integrado tienen evidencias distintas; no se acepta CI de un SHA antiguo. Cambios de contratos/datos/locks/configuración compartida afectan también consumidores. Git local hace commit/push; CI no se autocommitea. Reusable workflows directamente en .github/workflows; cancelación de CI redundante sin cancelar deploy/migración en curso.

GHCR registra digests del artefacto escaneado; configuración/volúmenes permanecen independientes de la imagen. Migraciones se prueban en DB desechables, compatibles por fases; rollback de imagen no revierte datos. Vincular release/commit/digest con Sentry/Prometheus/Grafana y registrar resultado. Leer [política completa](44-politica-commits-ci-cd-tests.md) para fases, responsabilidades, fallos y evidencia pendiente.
