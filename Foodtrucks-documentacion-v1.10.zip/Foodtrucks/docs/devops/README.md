# Guía de entrada a DevOps de Foodtrucks

**Versión:** 1.9 · **Fecha:** 14 de octubre de 2026. Manual de políticas y procedimientos previos al desarrollo. No hay workflows, aplicación, imágenes o servicios implementados/verificados en este paquete. Leer primero [la política de commits, pruebas y CI/CD](../44-politica-commits-ci-cd-tests.md) y [decisiones](../23-decisiones-pendientes.md).

## Qué leer según la tarea

| Necesidad | Documento y procedimiento |
| --- | --- |
| Arquitectura | [Monorepo](../07-arquitectura-monorepo.md), [servidor doméstico](../38-servidor-domestico.md) y política CI/CD: flujo commit → release |
| CI/CD y GitHub Actions | [Política operativa](../44-politica-commits-ci-cd-tests.md): cambios, eventos, gate, GHCR y fases |
| Pruebas locales/CI | [Testing y QA](../40-testing-qa-github.md): matriz de casos, aislamiento, comandos y evidencia |
| Seguridad | [DevSecOps](../39-seguridad-devsecops.md), [seguridad base](../19-seguridad.md): amenazas, scans y excepciones |
| Entornos | [Entornos](../21-entornos-ci-cd.md), [infraestructura](../17-infraestructura.md): separación y configuración |
| Despliegue | Política operativa §8–9 y servidor doméstico: digest, conexión, migración y health |
| Rollback y recuperación | Política §9, [fotos/backups](../18-media-backups-operacion.md): compatibilidad, restore y efectos externos |
| Secretos | Apartado siguiente, seguridad y [correo Resend](../30-correo-resend.md): mínimo privilegio y rotación |
| Monitorización | [Observabilidad](../41-observabilidad-grafana-prometheus-sentry.md): métricas, Sentry, alertas y runbooks |
| Marketing y datos | [Política de marketing](../31-marketing-digital-maestro.md), [medición/consentimiento](../34-analitica-consentimiento.md) |
| Gastos y recursos | [Presupuesto](../37-costes-presupuesto.md): cuotas conocidas, servicios/consumo pendientes |

Este índice organiza los manuales existentes. Las rutas de scripts/workflows del futuro repo se añadirán al implementar; no representa archivos ejecutables presentes.

## Glosario práctico

| Término | Significado en este proyecto |
| --- | --- |
| Workflow | Automatización GitHub Actions activada por un evento, con uno o más jobs |
| Job | Grupo de pasos que corre en un runner; puede depender de otros jobs |
| Step | Acción o comando dentro de un job; su fallo debe propagarse según la política |
| Runner | Máquina que ejecuta jobs; alojada por GitHub o propia con aislamiento requerido |
| Artifact | Archivo de resultado de una ejecución, como reporte/build; no confundir con caché |
| Cache | Datos reutilizados para acelerar una ejecución; nunca fuente de autorización o secretos |
| Secret | Credencial protegida, accesible solo al propósito/job/entorno autorizado |
| Environment | Entorno de despliegue y sus controles/variables/secretos en GitHub cuando estén disponibles |
| Release | Versión identificada con código, artefactos, compatibilidad y notas/evidencia |
| Deployment | Aplicación de una release a un entorno; necesita verificación posterior |
| Rollback | Retorno a una release estable compatible; no implica revertir automáticamente datos |
| SAST | Análisis estático del código para detectar riesgos de seguridad |
| SCA | Análisis de dependencias y vulnerabilidades conocidas |
| Coverage | Porción de código ejecutada por tests; no demuestra assertions buenas ni seguridad |
| Benchmark | Medición repetible de tiempo/allocs/recursos de una operación |
| Smoke test | Recorrido breve para verificar que una versión arranca y opera en sus funciones críticas |
| Digest | Identificador del contenido de una imagen; referencia estable para promoción/rollback |
| Gate | Comprobación obligatoria que bloquea integración/promoción si falta evidencia o hay fallos |
| SBOM | Inventario de componentes de una imagen/build que ayuda a rastrear dependencias |
| Expand-contract | Cambiar un esquema por fases para mantener compatibilidad antes de retirar lo antiguo |

## Preparación local y primera CI

1. Abrir el repositorio verdadero; leer README/AGENTS y ejecutar la auditoría de la política §2. Anotar gestor/versiones/scripts y comandos que existen, sin mostrar secretos.
2. Crear entorno de prueba independiente con datos sintéticos, PostgreSQL/PostGIS y Redis cuando sean necesarios. Verificar destino de la DB antes de migrar o limpiar; no usar volúmenes productivos.
3. Ejecutar los checks definidos por cada componente. Go puede usar `go test ./...`, `go test -race ./...`, `go vet ./...` y `go build ./...` desde el módulo real; estos comandos son referencia y **no se han ejecutado aquí**.
4. Para web/móvil usar scripts y lockfile del gestor real. Si un script falta, implementarlo cuando proceda o registrar bloqueo; no reemplazarlo por un comando que devuelve éxito sin hacer nada.
5. Validar workflows/scripts/configuración con herramienta compatible y ejecutar una PR de prueba propia. Confirmar éxito, fallo y selección de jobs, no solo parseo de YAML.

Fixtures de proveedor/fakes en CI rápido; pruebas sandbox autorizadas cuando deban validar integración real. Nunca reutilizar usuarios, pagos, destinatarios o secretos live. Si se implementa Compose, su validación local debe evitar imprimir valores interpolados: `docker compose config --quiet`, con paths/env reales y revisión de salida saneada. No añadir un Compose ficticio a este paquete.

## Secretos y configuración del administrador

Los nombres concretos deben coincidir con el código que se implemente. Esta tabla define **ubicación y privilegio propuestos**, no credenciales existentes ni obligación de poner todos los secretos en GitHub.

| Credencial/configuración | Ubicación mínima apropiada | Validación antes de activar |
| --- | --- | --- |
| Git para agente/editor | Autenticación local autorizada, fuera del repo | Remoto/rama/identidad y push de cambios propios |
| Token de publicación GHCR | Job confiable con `GITHUB_TOKEN` y permiso de paquete necesario | Propiedad del paquete, scope y registro del digest |
| Lectura de imagen privada desde casa | Credencial compatible GHCR de solo lectura, privada en host | Pull del digest permitido y rotación/revocación |
| Acceso de despliegue | Environment protegido o mecanismo privado restringido | Host/identidad verificados, comandos permitidos y aislamiento |
| PostgreSQL/Redis runtime | Configuración privada del entorno servidor | Usuarios/ACL mínimos, red privada y aislamiento DEV/staging/PROD |
| Stripe API/webhook | Backend/worker privado por entorno; CI rápida usa fakes | Firma/entorno/cuenta; prueba sin cargo live |
| Resend aplicación / alertas | Claves distintas en worker y servicio notificante | Dominio/propósito/destino autorizado, TLS e idempotencia |
| Mapbox | Token público mínimo por app/web; privado solo para build que lo requiera | Restricciones y scopes; no tratar token público como secreto backend |
| Google/Apple OAuth | Configuración pública e identidad de app; secretos servidor donde corresponda | Redirects/audiencias y canal real, sin acceso a otra cuenta |
| APNs/FCM y firma móvil | Entorno/servicio de envío y release móvil protegidos | App/entorno y dispositivos de prueba propios |
| Sentry | DSN según cliente; token privado solo en job de upload/release necesario | Saneamiento, release/artefactos y permisos mínimos |

Configurar reglas de rama, revisión y gate obligatorio; confirmar visibilidad/plan, Environments y permisos. Nunca abrir producción por no tener una función del plan: usar promoción manual restringida documentada. Registrar responsables y ruta de rotación; `.env.example` futura solo contendrá nombres/valores ficticios derivados de la implementación. No almacenar SMTP, claves privadas o certificados en Git/artifacts.

## Operar un despliegue o una recuperación

Para staging automático comprobar release/digests aprobados, entorno y configuración, capacidad y migración; ejecutar actualización y smoke, registrar resultado. Para producción verificar aprobación de esa misma release y compatibilidad con apps/esquema; aplicar el procedimiento restringido, comprobar health/recorridos y observar métricas/Sentry.

Ante fallo: congelar promociones, consultar el registro de la versión actual y anterior, revisar health/logs saneados y estado de migración. Volver a imágenes anteriores únicamente si el esquema es compatible. Si se necesita restore, aprobar y preparar su alcance, detener efectos externos y comprobar DB/fotos integrados; no borrar volúmenes ni lanzar migraciones destructivas como limpieza.

Los scripts exactos, flags y endpoints se documentarán desde el repo y la topología reales. No existe hoy un comando ejecutable de despliegue de Foodtrucks. [Política §9](../44-politica-commits-ci-cd-tests.md), [backups](../18-media-backups-operacion.md).

## Diagnóstico y mantenimiento

| Fallo | Primeras comprobaciones | Acción/evidencia |
| --- | --- | --- |
| CI falla | SHA/evento/job, primer error, versión y cambio afectado | Reproducir mismo comando/dataset; corregir causa y push nuevo |
| Check requerido no aparece | Evento, filtro, rama/base, selección y configuración de protección | Corregir activación/gate; no eliminar protección para fusionar |
| Job se salta inesperadamente | Resultado de detector/needs/condiciones | Bloquear y probar selección/fallo; no éxito por output vacío |
| GHCR no permite publicar/pull | Propiedad/visibilidad, vinculación, permisos y digest | Corregir privilegio mínimo; no imprimir credencial |
| Despliegue no conecta a casa | Ruta directa/Tunnel/administración elegida, host y red | Validar enlace seguro; no desactivar TLS/host checking ni exponer DB |
| Migración tarda/falla | Locks, versión de esquema, compatibilidad y estado de ejecución | Detener promoción; resolver con procedimiento revisado, no borrar datos |
| API falla después del cambio | Release/digests, readiness, configuración, DB/Redis, logs y Sentry | Rollback compatible o corrección; registrar incidente |
| Alerta no llega | Regla, canal/TLS, supresión, destinatario y límite proveedor | Prueba autorizada end-to-end y sonda externa si cae el domicilio |
| Disco/recursos crecen | Datos, imágenes, backups, logs, artifacts y retención | Limpiar solo objetos identificados según retención; no prune indiscriminado |

Logs de Actions: abrir ejecución y job del SHA registrado. Runtime: revisar servicios concretos con la herramienta del entorno y ventana temporal de la release; no exportar entornos completos o logs sensibles. Grafana/Sentry privados correlacionan versión, errores y recursos; métricas no sustituyen el ledger de pedidos/pagos.

Actualizar Actions/toolchains/scanners en cambios pequeños con SHA/versiones verificados, PR y checks. Revisar dependencias/excepciones, pruebas intermitentes, retención/costes, accesos y restore según calendario operativo por asignar. El calendario y destinatarios siguen pendientes; este manual no crea automaciones ni envía correos.

## Aceptación y pendientes

La política está lista para traslado cuando sus enlaces y decisiones son coherentes. La implementación solo se acredita con workflows válidos y ejecutados, scripts locales, tests/build, permisos, artefactos/digests, staging, recuperación y observabilidad demostrados. Un ensayo aislado no acredita producción.

**NO VERIFICADO:** repo/CI/cobertura, GHCR, builds nativas, credenciales/protecciones, conexión al domicilio, migraciones/deploy/rollback y alertas. Causa: no hay aplicación ni entornos disponibles en esta carpeta. Para completar la validación seguir las nueve fases de la política y guardar evidencia real. Capacidad productiva, RPO/RTO/SLO, mecanismo de acceso, responsables, versiones y costes variables permanecen en [decisiones pendientes](../23-decisiones-pendientes.md).

## Protección de datos y evidencias de calidad — v1.9

Leer [48. Política central](../48-proteccion-datos-gobernanza.md) al configurar accesos, retenciones, observabilidad, proveedores, backups o recuperación. Una restauración debe considerar las supresiones/restricciones posteriores al corte antes de volver a activar workers/tráfico. Las obligaciones de comunicación de posibles brechas se evalúan aparte de alertas operativas; canal y responsables reales siguen pendientes.

Reutilizar la trazabilidad requisito/riesgo/control/prueba/evidencia/responsable/estado de los cambios y releases. ISO/OWASP/NIST/CMMI orientan prácticas proporcionadas; no requieren desplegar herramientas adicionales ni demuestran cumplimiento por un pipeline verde. Las comprobaciones de este paquete son documentales; runbooks y controles efectivos deben ensayarse en los entornos reales.
